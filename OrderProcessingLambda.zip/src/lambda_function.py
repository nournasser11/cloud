import json
import boto3

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Orders')  # DynamoDB table name

def lambda_handler(event, context):
    for record in event['Records']:
        message = json.loads(record['body'])  # Parse the message from SQS

        order_id = message['orderId']
        user_id = message['userId']
        item_name = message['itemName']
        quantity = message['quantity']
        status = message['status']
        timestamp = message['timestamp']

        # Insert the item into DynamoDB
        try:
            table.put_item(
                Item={
                    'orderId': order_id,
                    'userId': user_id,
                    'itemName': item_name,
                    'quantity': quantity,
                    'status': status,
                    'timestamp': timestamp
                }
            )
            print(f"Order {order_id} processed successfully.")
        except Exception as e:
            print(f"Error processing order {order_id}: {e}")
            raise e  # If there's an error, raise it
